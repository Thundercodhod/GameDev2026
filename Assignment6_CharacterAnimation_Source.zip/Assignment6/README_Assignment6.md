# แบบฝึกหัดที่ 6 — ออกแบบตัวละคร 3D

ชุดงาน Blender + Mixamo + Godot ถูกแยกไว้ในโฟลเดอร์นี้เพื่อไม่กระทบฉากเกมเดิม

## ไฟล์สำคัญ

- `StudentAstronaut.blend` — ตัวละคร Low-poly ต้นฉบับจาก Blender
- `StudentAstronaut_ForMixamo.fbx` — T-pose ที่ใช้อัปโหลด Mixamo
- `Breathing Idle.fbx` — โมเดลที่ Rig แล้วพร้อมท่า Idle
- `Running.fbx` — Animation วิ่งจาก Mixamo
- `Jumping Up.fbx` — Animation กระโดดจาก Mixamo
- `StudentAstronaut_Mixamo.blend` — ไฟล์ Blender หลังรวม Animation
- `StudentAstronaut_Mixamo.glb` — โมเดลสำหรับ Godot มี Idle, Run และ Jump
- `character_animation_demo.tscn` — ฉาก Demo แสดง Animation
- `character_animation_demo.gd` — โหลด Mixamo BoneMap และเชื่อม Melee/Shooter Library

Animation Library ตามโจทย์อยู่ที่:

- `res://addons/Godot4-OpenAnimationLibraries/BoneMaps/Mixamo BoneMap.tres`
- `res://addons/Godot4-OpenAnimationLibraries/Libraries/Humanoid/MeleeLib.res`
- `res://addons/Godot4-OpenAnimationLibraries/Libraries/Humanoid/ShooterLib.res`

## วิธีเปิด Demo

1. เปิด `character_animation_demo.tscn` ใน Godot
2. กด **F6** เพื่อรันฉากนี้
3. ใช้ปุ่ม `Idle`, `Run`, `Jump`, `Melee Library` และ `Shooter Library`
4. ดับเบิลคลิกชื่อ Animation ในรายการเพื่อทดลองท่าอื่น

ฉากจะใช้ Mixamo BoneMap เป็นแหล่งการจับคู่กระดูก และปรับเส้นทาง Animation Library ให้ตรงกับ Mixamo Skeleton โดยไม่เปลี่ยนชื่อ Bone/Skin ของโมเดล

## ภาพหน้าจอสำหรับแบบฟอร์ม

1. Blender: เปิด `StudentAstronaut.blend` หรือใช้ `Screenshots/01_Blender_Character.png`
2. Mixamo: ภาพหน้า Auto-rig และภาพ Preview Animation ที่ถ่ายไว้ระหว่างทำ
3. Godot Editor: เปิด `character_animation_demo.tscn` ให้เห็น Scene Tree และรายชื่อ Animation
4. Godot Run: เลือกท่า `Melee/Slash1` หรือ `Shooter/shoot-pistol` แล้วถ่ายหน้าจอ

ผลทดสอบอัตโนมัติ: โหลดได้ 304 Animations, Skeleton 33 Bones และเล่น `Melee/Slash1` ได้
