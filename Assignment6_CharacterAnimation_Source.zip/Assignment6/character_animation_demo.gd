extends Node3D

const MELEE_SOURCE := preload("res://addons/Godot4-OpenAnimationLibraries/Libraries/Humanoid/MeleeLib.res")
const SHOOTER_SOURCE := preload("res://addons/Godot4-OpenAnimationLibraries/Libraries/Humanoid/ShooterLib.res")
const MIXAMO_BONE_MAP := preload("res://addons/Godot4-OpenAnimationLibraries/BoneMaps/Mixamo BoneMap.tres")

@onready var character: Node3D = $StudentAstronaut
@onready var animation_player: AnimationPlayer = character.find_child("AnimationPlayer", true, false)
@onready var skeleton: Skeleton3D = character.find_child("GeneralSkeleton", true, false)
@onready var status_label: Label = $UI/Margin/VBox/Status
@onready var animation_list: ItemList = $UI/Margin/VBox/AnimationList

var animation_names: Array[StringName] = []
var source_to_standard := {
	"mixamorig_Hips": "Hips", "mixamorig_Spine": "Spine",
	"mixamorig_Spine1": "Chest", "mixamorig_Spine2": "UpperChest",
	"mixamorig_Neck": "Neck", "mixamorig_Head": "Head",
	"mixamorig_LeftShoulder": "LeftShoulder", "mixamorig_LeftArm": "LeftUpperArm",
	"mixamorig_LeftForeArm": "LeftLowerArm", "mixamorig_LeftHand": "LeftHand",
	"mixamorig_LeftHandIndex2": "LeftIndexProximal",
	"mixamorig_LeftHandIndex3": "LeftIndexIntermediate",
	"mixamorig_LeftHandIndex4": "LeftIndexDistal",
	"mixamorig_RightShoulder": "RightShoulder", "mixamorig_RightArm": "RightUpperArm",
	"mixamorig_RightForeArm": "RightLowerArm", "mixamorig_RightHand": "RightHand",
	"mixamorig_RightHandIndex2": "RightIndexProximal",
	"mixamorig_RightHandIndex3": "RightIndexIntermediate",
	"mixamorig_RightHandIndex4": "RightIndexDistal",
	"mixamorig_LeftUpLeg": "LeftUpperLeg", "mixamorig_LeftLeg": "LeftLowerLeg",
	"mixamorig_LeftFoot": "LeftFoot", "mixamorig_LeftToeBase": "LeftToes",
	"mixamorig_RightUpLeg": "RightUpperLeg", "mixamorig_RightLeg": "RightLowerLeg",
	"mixamorig_RightFoot": "RightFoot", "mixamorig_RightToeBase": "RightToes",
}

func _ready() -> void:
	if MIXAMO_BONE_MAP == null or animation_player == null or skeleton == null:
		status_label.text = "โหลดตัวละครหรือ Mixamo BoneMap ไม่สำเร็จ"
		return
	animation_player.add_animation_library("Melee", MELEE_SOURCE)
	animation_player.add_animation_library("Shooter", SHOOTER_SOURCE)
	_refresh_animation_list()
	_play_preferred(["Idle"])

func _process(delta: float) -> void:
	character.rotate_y(delta * 0.10)

func _prepare_standard_skeleton() -> void:
	# Keep the imported node and bone names intact so the Skin and built-in Mixamo
	# animations continue to resolve. External library tracks are redirected below.
	pass

func _retarget_library(source: AnimationLibrary) -> AnimationLibrary:
	var result := AnimationLibrary.new()
	for animation_name in source.get_animation_list():
		var animation: Animation = source.get_animation(animation_name).duplicate(true)
		_retarget_animation(animation)
		result.add_animation(animation_name, animation)
	return result

func _retarget_animation(animation: Animation) -> void:
	var available_bones := {}
	var standard_to_source := {}
	for bone_index in skeleton.get_bone_count():
		available_bones[str(skeleton.get_bone_name(bone_index))] = true
	for source_name in source_to_standard:
		standard_to_source[source_to_standard[source_name]] = source_name
	for track_index in range(animation.get_track_count() - 1, -1, -1):
		var old_path := animation.track_get_path(track_index)
		var subnames := old_path.get_concatenated_subnames().split(":", false)
		if subnames.is_empty():
			continue
		var bone_name := subnames[0]
		if standard_to_source.has(bone_name):
			bone_name = standard_to_source[bone_name]
		if not available_bones.has(bone_name):
			animation.remove_track(track_index)
			continue
		animation.track_set_path(track_index, NodePath("MixamoSkeleton/Skeleton3D:" + bone_name))

func _refresh_animation_list() -> void:
	animation_list.clear()
	animation_names.clear()
	for name in animation_player.get_animation_list():
		animation_names.append(name)
		animation_list.add_item(str(name))
	status_label.text = "พร้อมใช้งาน %d ท่า — ดับเบิลคลิกชื่อท่าเพื่อเล่น" % animation_names.size()

func _play_preferred(candidates: Array[String]) -> void:
	for candidate in candidates:
		if animation_player.has_animation(candidate):
			animation_player.play(candidate, 0.2)
			status_label.text = "กำลังเล่น: " + candidate
			return
	status_label.text = "ไม่พบท่าที่เลือก"

func _on_animation_list_item_activated(index: int) -> void:
	if index >= 0 and index < animation_names.size():
		_play_preferred([str(animation_names[index])])

func _on_idle_pressed() -> void:
	_play_preferred(["Idle", "Melee/LightIdle", "Shooter/idle"])

func _on_run_pressed() -> void:
	_play_preferred(["Run", "Melee/LightRunning", "Shooter/run_067"])

func _on_jump_pressed() -> void:
	_play_preferred(["Jump", "Melee/Jump", "Shooter/jump"])

func _on_melee_pressed() -> void:
	_play_preferred(["Melee/Slash1", "Melee/Heavy1", "Melee/Stab1"])

func _on_shooter_pressed() -> void:
	_play_preferred(["Shooter/shoot-pistol", "Shooter/shoot-rifle-light", "Shooter/aim-pistol"])
