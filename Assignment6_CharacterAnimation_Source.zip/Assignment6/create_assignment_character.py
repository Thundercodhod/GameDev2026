import bpy
import math
from mathutils import Vector

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

MAT = {}
def material(name, color, metallic=0.0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1.0)
    m.metallic = metallic
    m.roughness = 0.55
    MAT[name] = m
    return m

white = material('Suit White', (0.72, 0.82, 0.9), 0.15)
blue = material('Suit Blue', (0.03, 0.22, 0.55), 0.35)
dark = material('Joint Dark', (0.025, 0.035, 0.06), 0.6)
glass = material('Visor Gold', (0.95, 0.42, 0.04), 0.65)

parts = []
def cube(name, loc, scale, mat, bevel=0.12):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    o = bpy.context.object
    o.name = name
    o.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    mod = o.modifiers.new('SoftEdges', 'BEVEL')
    mod.width = bevel
    mod.segments = 2
    o.data.materials.append(mat)
    parts.append(o)
    return o

def sphere(name, loc, scale, mat):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=1, location=loc)
    o = bpy.context.object
    o.name = name
    o.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    o.data.materials.append(mat)
    parts.append(o)
    return o

# Low-poly astronaut assembled in a clear T-pose for Mixamo auto-rigging.
cube('Torso', (0, 0, 1.75), (0.55, 0.30, 0.68), white, 0.18)
cube('ChestPanel', (0, -0.34, 1.72), (0.33, 0.08, 0.28), blue, 0.06)
sphere('Helmet', (0, 0, 2.75), (0.62, 0.55, 0.62), white)
sphere('Visor', (0, -0.47, 2.78), (0.43, 0.16, 0.35), glass)
cube('Backpack', (0, 0.40, 1.85), (0.38, 0.18, 0.48), blue, 0.08)

for side, sign in [('L', -1), ('R', 1)]:
    sphere('Shoulder_'+side, (sign*0.72, 0, 2.12), (0.22, 0.25, 0.25), blue)
    cube('UpperArm_'+side, (sign*1.13, 0, 2.10), (0.37, 0.18, 0.18), white, 0.10)
    sphere('Elbow_'+side, (sign*1.53, 0, 2.10), (0.18, 0.19, 0.19), dark)
    cube('LowerArm_'+side, (sign*1.86, 0, 2.10), (0.30, 0.16, 0.16), white, 0.08)
    sphere('Hand_'+side, (sign*2.20, 0, 2.10), (0.18, 0.20, 0.22), blue)
    sphere('Hip_'+side, (sign*0.31, 0, 1.02), (0.22, 0.24, 0.22), dark)
    cube('UpperLeg_'+side, (sign*0.31, 0, 0.63), (0.20, 0.23, 0.35), white, 0.10)
    sphere('Knee_'+side, (sign*0.31, -0.02, 0.24), (0.19, 0.22, 0.18), blue)
    cube('LowerLeg_'+side, (sign*0.31, 0, -0.12), (0.18, 0.21, 0.31), white, 0.08)
    cube('Boot_'+side, (sign*0.31, -0.10, -0.48), (0.24, 0.36, 0.16), dark, 0.08)

# Join into one mesh, ready for Mixamo's automatic skeleton.
bpy.ops.object.select_all(action='DESELECT')
for o in parts:
    o.select_set(True)
bpy.context.view_layer.objects.active = parts[0]
bpy.ops.object.convert(target='MESH')
bpy.ops.object.join()
character = bpy.context.object
character.name = 'StudentAstronaut'
bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

# Ground and camera only for a useful Blender screenshot; excluded from FBX export.
bpy.ops.mesh.primitive_plane_add(size=12, location=(0, 0, -0.66))
ground = bpy.context.object
ground.name = 'PreviewGround'
ground.data.materials.append(material('Ground', (0.035, 0.055, 0.10), 0.1))

bpy.ops.object.light_add(type='AREA', location=(4, -5, 7))
key = bpy.context.object
key.data.energy = 1100
key.data.shape = 'DISK'
key.data.size = 5
bpy.ops.object.light_add(type='AREA', location=(-4, 1, 4))
bpy.context.object.data.energy = 700
bpy.context.object.data.color = (0.15, 0.35, 1.0)

bpy.ops.object.camera_add(location=(5.8, -8.5, 3.5))
cam = bpy.context.object
bpy.context.scene.camera = cam
def point_at(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat('-Z', 'Y').to_euler()
point_at(cam, (0, 0, 1.1))

scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE'
scene.render.resolution_x = 1280
scene.render.resolution_y = 720
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.filepath = r'C:\Users\thuns\Documents\Game Dev\GodotGame\Game3D\Godot\MyFirst_3D_Game\Assignment6\Screenshots\01_Blender_Character.png'
scene.world.color = (0.008, 0.012, 0.03)

bpy.ops.wm.save_as_mainfile(filepath=r'C:\Users\thuns\Documents\Game Dev\GodotGame\Game3D\Godot\MyFirst_3D_Game\Assignment6\StudentAstronaut.blend')
bpy.ops.render.render(write_still=True)

# Export only the character in T-pose for Mixamo.
bpy.ops.object.select_all(action='DESELECT')
character.select_set(True)
bpy.context.view_layer.objects.active = character
bpy.ops.export_scene.fbx(filepath=r'C:\Users\thuns\Documents\Game Dev\GodotGame\Game3D\Godot\MyFirst_3D_Game\Assignment6\StudentAstronaut_ForMixamo.fbx', use_selection=True, apply_scale_options='FBX_SCALE_ALL', add_leaf_bones=False)


