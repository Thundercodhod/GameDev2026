extends "res://Scripts/Hazard.gd"

@export var patrol_offset := Vector3(2.0, 0.0, 0.0)
@export_range(0.5, 20.0, 0.1) var cycle_seconds: float = 4.0

var elapsed: float = 0.0

@onready var start_position: Vector3 = position

func _physics_process(delta: float) -> void:
	elapsed += delta

	var phase: float = elapsed * TAU / cycle_seconds
	position = start_position + patrol_offset * sin(phase)
