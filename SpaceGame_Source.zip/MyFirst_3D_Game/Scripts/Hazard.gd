extends Area3D

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node3D) -> void:
	if not body.is_in_group("Player"):
		return

	body.set_deferred(
		"global_position",
		%SpawnPosition.global_position
	)

	if body is CharacterBody3D:
		body.velocity = Vector3.ZERO
