extends Node3D

func _ready() -> void:
	GameManager.score = 0
