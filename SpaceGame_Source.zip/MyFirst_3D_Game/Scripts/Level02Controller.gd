extends Node3D

const REQUIRED := 7
var collected := 0
var checkpoint := Vector3(0, 0.7, 0)
var finished := false
var elapsed := 0.0
var respawn_lock := 0.0
@onready var player = $Player
@onready var hud: Label = $HUD/Status
@onready var notice: Label = $HUD/Notice

func _ready() -> void:
	GameManager.score = 0
	for item in $Energy.get_children():
		item.body_entered.connect(_collect.bind(item))
	for hazard in $Hazards.get_children():
		hazard.body_entered.connect(_hit)
	$Checkpoint.body_entered.connect(_checkpoint)
	$Extraction.body_entered.connect(_extract)
	$HUD/WinPanel/Buttons/Retry.pressed.connect(_retry)
	$HUD/WinPanel/Buttons/LevelOne.pressed.connect(_level_one)
	$HUD/WinPanel.hide()
	_update_hud()

func _physics_process(delta: float) -> void:
	if finished:
		return
	elapsed += delta
	respawn_lock = maxf(0.0, respawn_lock - delta)
	for hazard in $Hazards.get_children():
		var origin: Vector3 = hazard.get_meta("origin")
		var distance: float = hazard.get_meta("distance")
		hazard.position = origin + Vector3(sin(elapsed * 1.4 + float(hazard.get_index())) * distance, 0, 0)
	for item in $Energy.get_children():
		item.get_node("Visual").rotation.y += delta * 1.5
	if player.global_position.y < -10.0:
		_respawn()
	if collected == REQUIRED and $Extraction.overlaps_body(player):
		_extract(player)

func _collect(body: Node3D, item: Area3D) -> void:
	if body != player or item.get_meta("taken", false) or finished:
		return
	item.set_meta("taken", true)
	item.hide()
	item.set_deferred("monitoring", false)
	item.queue_free()
	collected += 1
	GameManager.score = collected
	AudioManager.coin_sfx.play()
	_update_hud()

func _hit(body: Node3D) -> void:
	if body == player:
		_respawn()

func _respawn() -> void:
	if respawn_lock > 0.0 or finished:
		return
	respawn_lock = 1.0
	player.set_deferred("global_position", checkpoint)
	player.velocity = Vector3.ZERO
	notice.text = "Returned to checkpoint. Collected energy is safe."

func _checkpoint(body: Node3D) -> void:
	if body != player or finished:
		return
	checkpoint = Vector3(1, 0.7, -17)
	notice.text = "CHECKPOINT SAVED - energy stays collected if you fall."
	$Checkpoint/Sign.modulate = Color(0.3, 1.0, 0.65)

func _update_hud() -> void:
	hud.text = "02  /  ORBITAL ESCAPE     |     ENERGY %d / %d" % [collected, REQUIRED]
	$Extraction/Sign.text = "BOARD SHIP" if collected == REQUIRED else "SHIP LOCKED\nENERGY %d / %d" % [collected, REQUIRED]

func _extract(body: Node3D) -> void:
	if body != player or finished:
		return
	if collected < REQUIRED:
		notice.text = "Collect all 7 energy cells before boarding the ship."
		return
	finished = true
	player.velocity = Vector3.ZERO
	player.set_process(false)
	player.set_physics_process(false)
	player.get_node("Gimbal").set_process_unhandled_input(false)
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	$HUD/WinPanel.show()
	notice.text = "MISSION COMPLETE"

func _retry() -> void:
	get_tree().reload_current_scene()

func _level_one() -> void:
	get_tree().change_scene_to_file("res://Scenes/level_01.tscn")
