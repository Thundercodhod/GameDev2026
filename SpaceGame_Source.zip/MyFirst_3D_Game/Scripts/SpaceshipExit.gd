extends Area3D

@export_file("*.tscn") var next_scene: String = ""
@export var required_energy: int = 5

@onready var status_label: Label3D = $StatusLabel

var player_inside: bool = false
var travelling: bool = false
var load_failed: bool = false

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _process(_delta: float) -> void:
	if travelling or load_failed:
		return

	if GameManager.score < required_energy:
		status_label.text = "ENERGY %d / %d" % [
			GameManager.score,
			required_energy
		]
		return

	status_label.text = "READY - BOARD SHIP"

	if player_inside:
		travelling = true
		status_label.text = "DEPARTING..."
		call_deferred("_travel")

func _on_body_entered(body: Node3D) -> void:
	if body.is_in_group("Player"):
		player_inside = true

func _on_body_exited(body: Node3D) -> void:
	if body.is_in_group("Player"):
		player_inside = false
		load_failed = false

func _travel() -> void:
	if next_scene.is_empty():
		_show_error("SET NEXT SCENE")
		return

	var result := get_tree().change_scene_to_file(next_scene)

	if result != OK:
		_show_error("CANNOT OPEN NEXT LEVEL")

func _show_error(message: String) -> void:
	travelling = false
	load_failed = true
	status_label.text = message
	push_error(message)
