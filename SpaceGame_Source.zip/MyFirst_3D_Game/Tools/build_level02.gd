extends SceneTree

const KIT = "res://Assets/Ultimate Space Kit-glb/"
var scene: Node3D

func _initialize() -> void:
	call_deferred("build")

func meshes(node: Node, trans := Transform3D.IDENTITY) -> Array:
	var result: Array = []
	if node is Node3D:
		trans = trans * node.transform
	if node is MeshInstance3D and node.mesh:
		result.append([node.mesh, trans])
	for child in node.get_children():
		result.append_array(meshes(child, trans))
	return result

func asset(parent: Node, file: String, target: Vector3, pos: Vector3, solid := false) -> Node3D:
	var source: Node3D = load(KIT + file).instantiate()
	var parts := meshes(source)
	var bounds: AABB = parts[0][1] * parts[0][0].get_aabb()
	for part in parts:
		bounds = bounds.merge(part[1] * part[0].get_aabb())
	var factor := target / bounds.size
	if target.y < 0:
		var s: float = target.x / maxf(bounds.size.x, bounds.size.z)
		factor = Vector3.ONE * s
	var visual := Node3D.new()
	visual.name = "Visual"
	parent.add_child(visual)
	visual.position = pos
	var normalization := Transform3D(Basis.from_scale(factor), -Vector3(bounds.get_center().x, bounds.position.y, bounds.get_center().z) * factor)
	for part in parts:
		var mesh := MeshInstance3D.new()
		mesh.mesh = part[0]
		mesh.transform = normalization * part[1]
		visual.add_child(mesh)
		if solid:
			var body := StaticBody3D.new()
			visual.add_child(body)
			var shape := CollisionShape3D.new()
			var faces: PackedVector3Array = mesh.mesh.get_faces()
			for i in faces.size():
				faces[i] = mesh.transform * faces[i]
			var collision := ConcavePolygonShape3D.new()
			collision.set_faces(faces)
			shape.shape = collision
			body.add_child(shape)
	source.free()
	return visual

func group_named(label: String) -> Node3D:
	var node := Node3D.new()
	node.name = label
	scene.add_child(node)
	return node

func area(parent: Node, label: String, pos: Vector3, size: Vector3) -> Area3D:
	var node := Area3D.new()
	node.name = label
	node.position = pos
	parent.add_child(node)
	node.collision_layer = 0
	node.collision_mask = 1
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	node.add_child(shape)
	return node

func sign_at(parent: Node, words: String, pos: Vector3, size := 38) -> Label3D:
	var label := Label3D.new()
	label.name = "Sign"
	label.text = words
	label.position = pos
	label.font_size = size
	label.pixel_size = 0.008
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.modulate = Color(0.55, 0.92, 1.0)
	parent.add_child(label)
	return label

func ownership(node: Node) -> void:
	for child in node.get_children():
		child.owner = scene
		ownership(child)

func build() -> void:
	scene = Node3D.new()
	scene.name = "Level02"
	scene.set_script(load("res://Scripts/Level02Controller.gd"))
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.008, 0.012, 0.035)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.6, 0.73, 1.0)
	env.ambient_light_energy = 0.7
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env_node.environment = env
	scene.add_child(env_node)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-45, -25, 0)
	sun.light_color = Color(1.0, 0.86, 0.68)
	sun.light_energy = 1.6
	sun.shadow_enabled = true
	scene.add_child(sun)
	var planets := group_named("Planets")
	var centers := [Vector3(0,0,0), Vector3(-1,0,-8.5), Vector3(1,0,-17), Vector3(-1,0,-25.5), Vector3(1,0,-34), Vector3(0,0,-42.5)]
	var variants := ["Planet-18Uxrb2dIc.glb", "Planet-4NxxeyYMPJ.glb", "Planet-5zzi8WUMXj.glb", "Planet-9g1aIbfR9Y.glb", "Planet-B7xd3SZq0z.glb", "Planet-EC1Lk2IamI.glb"]
	for i in centers.size():
		var planet := Node3D.new()
		planet.name = "Planet%02d" % (i+1)
		planets.add_child(planet)
		planet.position = centers[i]
		asset(planet, variants[i], Vector3(8, 1.4, 8), Vector3(0,-1.4,0), true)
		sign_at(planet, "%02d" % (i+1), Vector3(-2.7,1,0), 48)
	var player: Node3D = load("res://Scenes/player.tscn").instantiate()
	player.name = "Player"
	player.position = Vector3(0,0.7,0)
	player.set("jump_force", 8.0)
	scene.add_child(player)
	var energy := group_named("Energy")
	var energy_positions := [Vector3(0,1.2,-2.5),Vector3(-1,1.2,-8.5),Vector3(-0.3,1.2,-16),Vector3(2,1.2,-18),Vector3(-1,1.2,-25.5),Vector3(1,1.2,-34),Vector3(0,1.2,-41)]
	for i in energy_positions.size():
		var pickup := area(energy,"Energy%02d" % (i+1),energy_positions[i],Vector3(1.5,2.5,1.5))
		asset(pickup,"Pickup Thunder.glb",Vector3(0.7,-1,0),Vector3(0,-0.4,0))
	var hazards := group_named("Hazards")
	for i in 3:
		var pos: Vector3 = centers[i+1] + Vector3(0,1.0,-0.5)
		var hazard := area(hazards,"Drone%02d" % (i+1),pos,Vector3(1.0,1.6,1.0))
		hazard.set_meta("origin",pos)
		hazard.set_meta("distance",2.3)
		asset(hazard,"Enemy Flying.glb",Vector3(1.1,-1,0),Vector3(0,-0.5,0))
	var props := group_named("Decorations")
	asset(props,"Rover.glb",Vector3(1.8,-1,0),Vector3(-2,-0.35,0.5),true)
	asset(props,"Rock Large.glb",Vector3(1.3,-1,0),Vector3(-2,-0.4,-9.5),true)
	asset(props,"Solar Panel.glb",Vector3(1.5,-1,0),Vector3(2.5,-0.35,-16),true)
	asset(props,"Rock.glb",Vector3(1.1,-1,0),Vector3(2.4,-0.4,-33),true)
	asset(props,"Spaceship.glb",Vector3(3,-1,0),Vector3(0,-0.25,-44),true)
	var checkpoint_area := area(scene,"Checkpoint",Vector3(1,1,-17),Vector3(5,4,5))
	sign_at(checkpoint_area,"CHECKPOINT",Vector3(0,2.5,0))
	var exit_area := area(scene,"Extraction",Vector3(0,1,-42),Vector3(3,4,2))
	sign_at(exit_area,"SHIP LOCKED",Vector3(0,3,-1))
	sign_at(scene,"ORBITAL ESCAPE\nFollow the numbered planets",Vector3(0,3,-2),40)
	var stars := group_named("Stars")
	var rng := RandomNumberGenerator.new()
	rng.seed = 2042
	var star_mesh := SphereMesh.new()
	star_mesh.radius = 0.08
	star_mesh.height = 0.16
	star_mesh.radial_segments = 4
	star_mesh.rings = 2
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(0.6,0.8,1)
	star_mesh.material = material
	for i in 140:
		var star := MeshInstance3D.new()
		star.mesh = star_mesh
		star.position = Vector3(rng.randf_range(-75,75),rng.randf_range(10,55),rng.randf_range(-95,25))
		stars.add_child(star)
	var hud := CanvasLayer.new()
	hud.name = "HUD"
	scene.add_child(hud)
	var status := Label.new()
	status.name = "Status"
	status.position = Vector2(24,20)
	status.add_theme_font_size_override("font_size",26)
	hud.add_child(status)
	var notice := Label.new()
	notice.name = "Notice"
	notice.position = Vector2(24,58)
	notice.text = "Move: WASD   |   Jump: Space (twice)   |   Collect 7 energy cells and reach the ship"
	notice.add_theme_font_size_override("font_size",17)
	hud.add_child(notice)
	var panel := PanelContainer.new()
	panel.name = "WinPanel"
	panel.position = Vector2(260,180)
	panel.custom_minimum_size = Vector2(620,260)
	hud.add_child(panel)
	var buttons := VBoxContainer.new()
	buttons.name = "Buttons"
	buttons.add_theme_constant_override("separation",20)
	panel.add_child(buttons)
	var title := Label.new()
	title.text = "MISSION COMPLETE\nAll energy recovered. Your crew is going home."
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size",24)
	buttons.add_child(title)
	for info in [["Retry","PLAY LEVEL 2 AGAIN"],["LevelOne","RETURN TO LEVEL 1"]]:
		var button := Button.new()
		button.name = info[0]
		button.text = info[1]
		button.custom_minimum_size.y = 48
		buttons.add_child(button)
	ownership(scene)
	# Keep the character as an instance so later character fixes carry over.
	for child in player.get_children():
		clear_owner(child, player)
	var packed := PackedScene.new()
	var error := packed.pack(scene)
	if error == OK:
		error = ResourceSaver.save(packed,"res://Scenes/level_02.tscn")
	print("BUILD_LEVEL02_RESULT=",error)
	scene.free()
	quit(error)

func clear_owner(node: Node, player: Node) -> void:
	node.owner = player
	for child in node.get_children():
		clear_owner(child, player)
