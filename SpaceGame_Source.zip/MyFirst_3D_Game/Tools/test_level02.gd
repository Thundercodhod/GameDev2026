extends SceneTree

var failures := 0
func _initialize() -> void:
	call_deferred("run")

func check(value: bool, message: String) -> void:
	print("PASS: " if value else "FAIL: ", message)
	if not value:
		failures += 1

func frames(count: int) -> void:
	for i in count:
		await physics_frame

func run() -> void:
	change_scene_to_file("res://Scenes/level_02.tscn")
	await scene_changed
	await frames(40)
	var level = current_scene
	var player = level.get_node("Player")
	check(player.is_on_floor(), "Player spawns on the actual planet collision")
	check(level.collected == 0, "Fresh level starts with zero energy")
	level._extract(player)
	check(not level.finished, "Ship stays locked before all energy is collected")
	# Exercise the real controller and jump input across every neighboring pair.
	for hazard in level.get_node("Hazards").get_children():
		hazard.monitoring = false
	var planets := level.get_node("Planets").get_children()
	for i in range(planets.size() - 1):
		var start: Vector3 = planets[i].position
		var target: Vector3 = planets[i + 1].position
		player.global_position = Vector3(target.x, 0.5, start.z - 1.0)
		player.velocity = Vector3.ZERO
		player.get_node("Gimbal").rotation = Vector3.ZERO
		await frames(20)
		Input.action_press("move_forward")
		await frames(20)
		Input.action_press("jump")
		await process_frame
		await process_frame
		Input.action_release("jump")
		await frames(45)
		Input.action_release("move_forward")
		await frames(12)
		print("JUMP_END ", i, " pos=",player.position," target=",target," floor=",player.is_on_floor())
		check(player.is_on_floor() and absf(player.position.z - target.z) < 3.5, "Real controller can jump from planet %d to %d" % [i+1,i+2])
	# Restart to independently test objectives after traversal.
	change_scene_to_file("res://Scenes/level_02.tscn")
	await scene_changed
	await frames(30)
	level = current_scene
	player = level.get_node("Player")
	for planet in level.get_node("Planets").get_children():
		var origin: Vector3 = planet.global_position
		var query := PhysicsRayQueryParameters3D.create(origin + Vector3(0,6,0),origin - Vector3(0,6,0))
		query.exclude = [player.get_rid()]
		var hit: Dictionary = player.get_world_3d().direct_space_state.intersect_ray(query)
		check(not hit.is_empty(), "Surface exists at " + planet.name)
	# Trigger actual Area3D entry, not just score assignment.
	player.global_position = level.get_node("Energy/Energy01").global_position
	player.velocity = Vector3.ZERO
	await frames(5)
	check(level.collected == 1, "Touching an energy cell collects it once")
	player.global_position = Vector3(1,0.7,-17)
	player.velocity = Vector3.ZERO
	await frames(6)
	check(level.checkpoint.z == -17, "Midpoint checkpoint activates through collision")
	var before: int = level.collected
	player.global_position = Vector3(0,-12,0)
	await frames(4)
	check(player.global_position.distance_to(level.checkpoint) < 1.0, "Falling returns to checkpoint")
	check(level.collected == before, "Collected energy survives falling")
	level.respawn_lock = 0.0
	player.global_position = level.get_node("Hazards/Drone03").global_position
	player.velocity = Vector3.ZERO
	await frames(5)
	check(player.global_position.distance_to(level.checkpoint) < 1.0, "Drone collision returns player to checkpoint")
	for pickup in level.get_node("Energy").get_children():
		player.global_position = pickup.global_position
		player.velocity = Vector3.ZERO
		await frames(5)
	check(level.collected == 7, "All seven energy cells can be collected")
	player.global_position = level.get_node("Extraction").global_position
	await frames(5)
	check(level.finished and level.get_node("HUD/WinPanel").visible, "Boarding with full energy displays mission complete")
	check(ResourceUID.get_id_path(ResourceUID.text_to_id("uid://dytlous3kp4ve")) == "res://Scenes/level_02.tscn", "Level 1 destination UID still resolves to Level 2")
	print("LEVEL02_TEST_FAILURES=",failures)
	quit(failures)
